<?php
$daysmartsync_prefix = 'dsaioc_';

function dsaioc_get_ical_uid($e)
{
    $ical_uid = $e->uid;
    return $ical_uid;
}

function dsaioc_add_vcalendar_events_to_db($events = array(), array $args = null, $current_page = 1, $last_page = 10, $all_resources = null, $all_event_types = null)
{

    $feed = isset($args['feed']) ? $args['feed'] : null;
    $comment_status = isset($args['comment_status']) ? $args['comment_status'] : 'open';
    $do_show_map = isset($args['do_show_map']) ? $args['do_show_map'] : 0;
    $count = 0;
    $events_in_db = count($events);
    $feed_name = 'Sync DaySmart iCals-' . strtotime(date('Y-m-d H:i:s'));

// Fetch default timezone in case individual properties don't define it
    $local_timezone = 'UTC';


    $messages = 'Debug the issue.';

// go over each event
    foreach ($events as $e) {
        // Event data array, and posts data array
        $dataAllInOneEvents = array();
        $dataNewPosts = array();

//        if($count > 0){ continue; }// to limit the records
        $dataAllInOneEvents['ical_uid'] = $e->id;

        $e = $e->attributes;
//echo '<pre>'; print_r($e); exit;

        $resource_id = $e->resource_id;
        $resourceInfo = array();
        foreach ($all_resources as $resource) {
            if ($resource->id == $resource_id) {
                $resourceInfo = $resource->attributes;
            }
        }

        $event_type_code = $e->event_type;
        $eventTypeId = '';
        foreach ($all_event_types as $eventType) {
            if ($eventType->attributes->code == $event_type_code) {
                $eventTypeId = '&event_type=' . $eventType->id;
            }
        }

        // =====================
// = Start & end times =
// =====================
        $start = $e->start_gmt;
        $end = $e->end_gmt;

// For cases where a "VEVENT" calendar component
// specifies a "DTSTART" property with a DATE value type but none
// of "DTEND" nor "DURATION" property, the event duration is taken to
// be one day.  For cases where a "VEVENT" calendar component
// specifies a "DTSTART" property with a DATE-TIME value type but no
// "DTEND" property, the event ends on the same calendar date and
// time of day specified by the "DTSTART" property.
        if (empty($end)) {
            // #2 if only DATE value is set for start, set duration to 1 day
            $end = $start;
        }

        $start = strtotime($start);
        $end = strtotime($end);

        if (false === $start || false === $end) {
            echo 'No proper event is there.';
            wp_die();
        }

        // If all-day, and start and end times are equal, then this event has
        // invalid end time (happens sometimes with poorly implemented iCalendar
        // exports, such as in The Event Calendar), so set end time to 1 day
        // after start time.

        $dataAllInOneEvents += compact('start', 'end');
        // =======================================
        // = Recurrence rules & recurrence dates =
        // =======================================
        $rrule = array(); //$e->rrule;
        $rdate = array(); //$e->rdate;

// =======================================
// = Exclusion rules & exclusion dates   =
// =======================================
        $exrule = array(); //$e->exrule;
        $exdate = array(); //$e->exdate;

// ===================
// = Venue & address =
// ===================
        $dataAllInOneEvents['country'] = '';
        $dataAllInOneEvents['city'] = '';
        $dataAllInOneEvents['province'] = '';
        $dataAllInOneEvents['postal_code'] = '';

        $venue = 'IceWorks Skating Complex - r';

        if (isset($resourceInfo->desc)) {
            $venue = !empty(trim($resourceInfo->desc)) ? $resourceInfo->desc : $venue;
        }

        $address = '';
        $location = '';
        if (isset($resourceInfo->name)) {
            $address = $resourceInfo->name . ' - ' . $venue;
        }

        $matches = array();

// =====================================================
// = Set show map status based on presence of location =
// =====================================================
        $event_do_show_map = 0;

// ==================
// = Cost & tickets =
// ==================
        $cost = array('cost' => 0, 'is_free' => 1);
        $ticket_url = "https://apps.daysmartrecreation.com/dash/x/#/online/iceworks/calendar?location=1&start=$e->start_gmt&end=$e->end_gmt" . $eventTypeId;

// ===============================
// = Contact name, phone, e-mail =
// ===============================
// Initialize default values
        $dataAllInOneEvents['contact_email'] = '';
        $dataAllInOneEvents['contact_url'] = '';
        $dataAllInOneEvents['contact_phone'] = '';
        $dataAllInOneEvents['contact_name'] = '';
        $e->desc = empty($e->desc) ? 'Daysmart Event - ' . $dataAllInOneEvents['ical_uid'] : $e->desc;
        $description = stripslashes(
            str_replace(
                '\n',
                "\n",
                $e->desc
            ));

        // Create event related table entries.
        //Creating event into wordpress post table
        $dataNewPosts = array(
            'post_status' => 'publish',
            'comment_status' => $comment_status,
            'post_type' => 'ai1ec_event',
            'post_author' => 1,
            'post_title' => $e->desc,
            'post_content' => $description
        );
        // print_r($e);
        $eventPostId = wp_insert_post($dataNewPosts, true);

        global $wpdb;
        //Creating event into ain1ec events table
        $dataAllInOneEvents += array(
            'post_id' => $eventPostId,
            'recurrence_rules' => $rrule,
            'exception_rules' => $exrule,
            'recurrence_dates' => $rdate,
            'exception_dates' => $exdate,
            'venue' => $venue,
            'address' => $address,
            'cost' => $cost,
            'ticket_url' => $ticket_url,
            'show_map' => $event_do_show_map,
            'ical_feed_url' => $feed->feed_url,
            'ical_source_url' => $e->url,
            'ical_organizer' => 'IceWorks',
            'ical_contact' => ' (610) 497-2200',
            'ical_uid' => dsaioc_get_ical_uid($e)
        );

        $events_table_name = $wpdb->prefix . 'ai1ec_events';
        $ai1ec_event_id = $wpdb->insert($events_table_name, $dataAllInOneEvents);

        //Creating record for event instances table
        $events_table_name = $wpdb->prefix . 'ai1ec_event_instances';
        $ai1ec_event_instance_id = $wpdb->insert($events_table_name, array(
                'post_id' => $eventPostId,
                'start' => $start,
                'end' => $end)
        );
        $count++;
    } //close while iteration

    return array(
        'current_page' => $current_page,
        'last_page' => $last_page,
        'count' => $count,
        'total_events_api' => $events_in_db,
        'messages' => $messages,
        'name' => 'Daysmart Events Sync',
    );

}
